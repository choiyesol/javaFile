package reference;

public class Student1 {
	int studentID;
	String studentname;
	int koreaScore;
	int mathScore;

}
