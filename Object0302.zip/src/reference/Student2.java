package reference;

public class Student2 {
	int studentID;
	String studentname;
	int koreaScore;
	int mathScore;
	String koreaSubject;
	String mathSubject;
}
