package object;

public class Report {
	String studentName;
	String where;
	int kor=80;
	int eng=70;
	int mat=60;
	int tot=kor+eng+mat;
	
	public String getstudentNme() {
		return "�л��̸�: "+studentName;
	}
	public String getwhere() {
		return "�л��а�: "+where;
	}
	public String getkor() {
		return "��������: "+kor;
	}
	public String geteng() {
		return "��������: "+eng;
	}
	public String getmat() {
		return "��������: "+mat;
	}
	public String gettot() {
		return "����: "+tot;
	}
	public float getavg() {
		float avg=(float)(kor+eng+mat)/3.0F;
		return avg;
	}
	public String getisu() {
		float avg=(float)(kor+eng+mat)/3.0F;
		String res;
		if(avg>=60) {
		res="�̼�";
		}else {
		res="���̼�";
		}
		return res;
		}
	
	//���� �Լ�		
	public static void main(String[] args) {
		Report tt = new Report();
		tt.studentName="�ڸ���";
		tt.where="���а�";
		tt.kor=80;
		tt.eng=70;
		tt.mat=60;
		
		System.out.println(tt.getstudentNme());
		System.out.println(tt.getwhere());
		System.out.println(tt.getkor());
		System.out.println(tt.geteng());
		System.out.println(tt.getmat());
		System.out.println(tt.gettot());
		System.out.println(tt.getavg());
		System.out.println(tt.getavg());
		System.out.println(tt.getisu());

	}

}
