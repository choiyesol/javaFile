package object;

public class Student1 {

}
