package hiding;

public class StudenttTest {
	
		public static void main(String[]args) {
			Student studentLee = new Student();
			
			//studentLee.studentName = "�̻��";
			
			studentLee.grade = 10;
			studentLee.address = "��⵵";
			
			System.out.println(studentLee.getStudentName("������"));
		
	}

}
