package shopping;

public class Store {
String name;
int money;

Store(String name,int money){
	this.name=name;
	this.money=money;
}
public void buylotte(Lotte lmenu,int money) {
	String message=lmenu.brewing(300000);
		this.money-=money;
		System.out.println(name+"�� "+money+"������ "+message);
	}

public void buyhyundae(Hyundae Hmenu,int money) {
	String message=Hmenu.brewing(240000);
		this.money-=money;
		System.out.println(name+"�� "+money+"������ "+message);
}
}
