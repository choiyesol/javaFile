package shopping;

public class Person {
	public static final int lotte_sandal=300000;
	public static final int lotte_shorts=260000;
	
	public static final int hyundae_sandal=28000;
	public static final int hyundae_shorts=240000;
}
